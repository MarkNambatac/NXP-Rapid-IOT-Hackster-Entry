#ifndef ATMO_TYPEDEFS_H
#define ATMO_TYPEDEFS_H

#define ATMO_PLATFORM_NO_SSCANF_SUPPORT

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#endif
